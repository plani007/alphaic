import numpy as np
import logging
import cv2
import os

def compare_outs(board_out , ref_out):
	if board_out.shape != ref_out.shape:
	    raise Exception("board_out shape doesnt match with the ref_out shape")
	index = 0
	wrong_out = False
	for board_data , ref_data in zip(board_out.flatten() , ref_out.flatten()):
	    if int(board_data) != int(ref_data):
	        print(f" ERROR : board value ({board_data}) and ref value ({ref_data}) for index {index} doesnt match !!!")
	        wrong_out = True
	        break

	    index += 1

	if wrong_out == False:
	    print("Board data and ref data exactly match , Hoorray!!!!!")

def create_input(shape , low = -128 , high = 127):
    if shape is None:
        raise Exception("Size cannot be None")
    image = np.random.randint(low = low , high = high , size = shape)
    return image

def read_input(shape , input_path , cv2 = True , txt = False ,  npy = False):
    if npy:
        image = np.load(input_path)
    elif txt:
        image = np.loadtxt(input_path)
    elif cv2:
        image = cv2.imread(input_path)
    else:
        raise Exception("invalid file format")
    image = np.array(image).reshape(shape)
    return image
