###########################################################################
# Copyright (C) AlphaICs Private Limited, India - All Rights Reserved
#
# Unauthorized copying of this file, via any medium is strictly prohibited
#
# Proprietary and confidential
#
# author : Vaibhav Nandwani <vaibhav.nandwani@alphaics.com> 2021
# author : Shivam Garg <shivam.garg@alphaics.com> 2021
###########################################################################

import os
os.environ['CUDA_VISIBLE_DEVICES'] = ''
import argparse
import copy
import pickle
import re
import sys
import cv2
import networkx as nx
import numpy as np
import tensorflow as tf
import pickle
tf.compat.v1.disable_eager_execution()
import AlphaNE.Compile_Engine.Quantization_tool.load_tf_model
from AlphaNE.Compile_Engine.Quantization_tool.load_tf_model import Model
from AlphaNE.Compile_Engine.Quantization_tool.Parser import Parser
from AlphaNE.Compile_Engine.Quantization_tool.Getnet import Get_Net
import AlphaNE.Compile_Engine.Quantization_tool.utils
import glob
import random
from AlphaNE.Compile_Engine.Quantization_tool.preprocessing import *

def quant_inference(model_path , image , input_tensor , output_tensors , quant_load_path , data_path, shape = None , input_scale = None , preprocess = None):
    inputs = input_tensor
    outputs = output_tensors
    data_path = data_path
    if preprocess is None:
        preprocess = default_func
    if type(image)==str:
        input_shape = [None]
        input_shape.extend(shape[1:])
        data_tmp=create_data(callibration_data_path,preprocess,1,tuple(input_shape[1:3]))
        if input_scale is None:
            input_scale = 127 / abs(data_tmp).max()
        data_tmp=np.array(np.round(data_tmp*input_scale,decimals=0),dtype= np.float32)
        data_tmp = np.clip(data_tmp , -128 , 127)
    else:
        input_shape = [None]
        input_shape.extend(list(image.shape))
        data_tmp=np.expand_dims(image,axis=0)
    np.save(data_path,data_tmp)
    getnet=Get_Net(quant=False,inference=True)

    inverse_inter_layer=np.load(quant_load_path+"inverse_inter_layer.npy",allow_pickle = True).item()
    act_s_dict=np.load(quant_load_path+"act_s_dict.npy", allow_pickle = True).item()
    getnet.bias_quantized=np.load(quant_load_path+"bias_quantized.npy" ,allow_pickle = True).item()
    getnet.weights_quantized=np.load(quant_load_path+"weights_quantized.npy", allow_pickle = True).item()

    model=Model(model_path,data_path,data_path,input_shape)
    nodes=model.graph_def.node
    ans=model.run_model(inputs,outputs,1)
    infer_model=Parser(nodes,inputs,input_shape,quant_compatiable=False,quant_inference=True,float_inference=False,
                    inverse_inter_layer=inverse_inter_layer,getnet=getnet)
    infer_model.build()
    data=np.load(data_path)
    int_outs = []
    for i in range(len(outputs)):
        out_int = infer_model(outputs[i],data,act_s_dict=act_s_dict)
        int_outs.append(out_int)
    return int_outs
