from AlphaNE.Gluon_Interpreter.quant_inference import quant_inference
from AlphaNE.Compile_Engine.compiler.compile import Compiler
import AlphaNE.Gluon_Interpreter.utils as debug_utils
from AlphaNE.Runtime_Engine.runtime import Runtime
import numpy as np
import shutil
import pdb
import os

class GluonInterpreter():
    def __init__(self , model_path , cal_images_path , execution_dir):
        self.model_path = model_path
        print(self.model_path)
        self.execution_dir = execution_dir
        print(self.execution_dir)
        self.cal_images_path = cal_images_path
        print(self.cal_images_path)
        self.quant_path = execution_dir + "/data/quant_data/"
        self.model_name = model_path.split("/")[-1].split(".pb")[0]
        self.runtime_config_path = execution_dir + "/data/runtime_config.json"
        self.runtime_const_dict_path = execution_dir + "/data/constant_config.pickle"
        self.output_data = execution_dir + "/data/output_data/"
        if os.path.exists(self.output_data):
            shutil.rmtree(self.output_data)
        os.makedirs(self.output_data)

    def define_compiler(self ,
                    input_tensors ,
                    output_tensors):
        self.rap_compiler = Compiler(self.model_path ,
                                  self.cal_images_path ,
                                  self.model_name ,
                                  input_tensors = input_tensors ,
                                  output_tensors = output_tensors,
                                  execution_dir_path = self.execution_dir)

    def compile_model(self,
                      quantize_model ,
                      save_org = True ,
                      float_ops = None ,
                      preprocess = None ,
                      ddr_debug = False ,
                      plot_segments = True ,
                      print_mem_info = True ,
                      save_quant_info = True ,
                      reuse_quant_data = None ,
                      plot_deserealized_graph = True):

        self.rap_compiler.compile_model(quantize_model ,
                                   save_org = save_org ,
                                   ddr_debug = ddr_debug ,
                                   preprocess = preprocess ,
                                   user_float_ops = float_ops ,
                                   plot_segments = plot_segments ,
                                   print_mem_info = print_mem_info ,
                                   save_quant_info = save_quant_info ,
                                   reuse_quant_data = reuse_quant_data ,
                                   plot_deserealized_graph = plot_deserealized_graph)

    def define_runtime(self):
        self.rap_runtime = Runtime(self.runtime_config_path , self.runtime_const_dict_path , self.quant_path , self.model_name)


    def run_on_gluon(self, frame):
        images=frame
        input_scale = 127 / abs(np.asarray(images)).max()
        for i in range(len(images)):
            images[i]=np.array(np.round(images[i]*input_scale,decimals=0),dtype= np.float32)
            images = np.clip(images , -128 , 127)


        output = self.rap_runtime.run([images])
        return output


    def run(self,
            input_tensors,
            output_tensors,
            quantize_model ,
            save_org = True ,
            float_ops = None,
            preprocess = None ,
            ddr_debug = False ,
            plot_segments = True ,
            compile_model = True ,
            print_mem_info = True ,
            save_quant_info = True ,
            reuse_quant_data = None ,
            plot_deserealized_graph = True):


        if not compile_model:
            self.define_runtime()

        else:
            self.define_compiler(input_tensors,
                                 output_tensors)
            self.compile_model(quantize_model ,
                               save_org = save_org ,
                               float_ops = float_ops ,
                               ddr_debug = ddr_debug ,
                               preprocess = preprocess ,
                               plot_segments = plot_segments ,
                               print_mem_info = print_mem_info ,
                               save_quant_info = save_quant_info ,
                               reuse_quant_data = reuse_quant_data ,
                               plot_deserealized_graph = plot_deserealized_graph)
            self.define_runtime()
