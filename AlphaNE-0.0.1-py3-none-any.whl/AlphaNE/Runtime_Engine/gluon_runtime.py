from AlphaNE.Runtime_Engine import utils as runtime_utils
import numpy as np
import traceback
import json
import pdb
import os

class Gluon_Runtime():
    def __init__(self , runtime_dir ,
                 input_dir ,
                 output_dir ,
                 runtime_path ,
                 ddr_path ,
                 bin_path ,
                 curr_dir_path ,
                 nodes_dict ,
                 dequant_scales):

        self.ddr_path = ddr_path
        self.bin_path = bin_path
        self.input_dir = input_dir
        self.output_dir = output_dir
        self.nodes_dict = nodes_dict
        self.runtime_dir = runtime_dir
        self.runtime_path = runtime_path
        self.curr_dir_path = curr_dir_path
        self.dequant_scales = dequant_scales
        self.seg_conf_path = os.path.join(self.runtime_path , "data/config")
        os.chdir(self.runtime_dir)
        os.system("./build.sh {} {}".format(self.ddr_path , self.bin_path))
        os.chdir(self.curr_dir_path)
        # print("Initialised board ...")

    def dequantize_outputs(self , outputs , seg_out_order):
        dq_outs = []
        for index , seg_out in enumerate(seg_out_order):
            if seg_out not in self.dequant_scales:
                raise Exception("dequant scale for out node {} not available".format(seg_out))
            dq_scale = self.dequant_scales[seg_out]
            dq_outs.append(outputs[index] * dq_scale)

        return dq_outs

    def read_outputs(self):
        outputs = runtime_utils.extract_outputs(self.output_dir)
        return outputs

    def write_outputs(self , outputs):
        for index , output in enumerate(outputs):
            runtime_utils.write_inp_to_txt(output , self.input_dir + "DC{}.txt".format(index))

    def get_segment_inp_addrs(self , input_order):
        input_addrs = []
        for inp_name in input_order:
            inp_node = self.nodes_dict[inp_name]
            input_addrs.append(inp_node["out_data_addr"])
        return input_addrs

    def get_segment_out_info(self , segment_outputs):
        output_addrs = []
        output_sizes = []
        for name in segment_outputs:
            node = self.nodes_dict[name]
            output_addrs.append(node["out_data_addr"])
            output_sizes.append(node["size"])

        return output_addrs , output_sizes

    def gen_config(self , input_addrs , output_addrs , output_sizes , seg_id):
        with open(self.seg_conf_path , "w") as conf_file:
            conf_file.write("[INPUT]\n")
            conf_file.write("input_dir_path = {}\n".format(self.input_dir))
            conf_file.write("\n")

            conf_file.write("[INPUT_LOCATIONS]\n")
            for i in range(len(input_addrs)):
                conf_file.write("input_location_{} = {}\n".format(i , input_addrs[i]))
            conf_file.write("\n")

            conf_file.write("[OUTPUT]\n")
            conf_file.write("output_dir_path = {}\n".format(self.output_dir))
            conf_file.write("\n")

            conf_file.write("[OUTPUT_LOCATIONS]\n")
            for i in range(len(output_addrs)):
                conf_file.write("output_location_{} = {}\n".format(i , output_addrs[i]))
            conf_file.write("\n")
            conf_file.write("[OUTPUT_SIZES]\n")
            for i in range(len(output_addrs)):
                conf_file.write("output_size_{} = {}\n".format(i , output_sizes[i]))
            conf_file.write("\n")

        # print("Config file for current runtime segment ({}) is generated".format(seg_id))

    def run_on_gluon(self, segment_data , segment_id , inputs_this_segment , final_segment = False , convert_to_float = False , input_order = None , starting_inp_addrs = None):
        if segment_data["type"] == "HOST":
            raise Exception("segment runtime type mismatch , expected : BOARD , found : HOST")
        self.segment_data = segment_data
        input_nodes = segment_data["inputs"]
        output_nodes = segment_data["outputs"]
        self.write_outputs(inputs_this_segment)
        if input_order is None:
            if starting_inp_addrs is None:
                raise Exception("initial input address for starting segment is not present")
            input_addrs = starting_inp_addrs
        else:
            input_addrs = self.get_segment_inp_addrs(input_order)

        output_addrs , output_sizes = self.get_segment_out_info(segment_data["outputs"])
        self.gen_config(input_addrs , output_addrs , output_sizes , segment_id)
        os.chdir(self.runtime_dir)
        os.system("./execute {}".format(self.seg_conf_path))
        os.chdir(self.curr_dir_path)
        outputs_this_segment = self.read_outputs()
        if final_segment and convert_to_float:
            dequantized_outs = self.dequantize_outputs(outputs_this_segment)
        return outputs_this_segment
