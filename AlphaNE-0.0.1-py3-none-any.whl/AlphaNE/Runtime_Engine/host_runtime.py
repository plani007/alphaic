from importlib import import_module
import numpy as np
import traceback
import json
import pdb
import os

class Host_Runtime():
    def __init__(self ,
                 nodes_dict ,
                 const_dict ,
                 dequant_scales ,
                 quant_scales):

        self.float_nodes = {}
        self.processed_nodes = {}
        self.nodes_dict = nodes_dict
        self.const_dict = const_dict
        self.quant_scales = quant_scales
        self.dequant_scales = dequant_scales
        # self.module_path = "AlphaNE.Runtime_Engine.float_operations.float_ops"
        # self.mod = import_module(self.module_path)

    def dequantize_input(self , input , dequantize_factor):
        dequantized_input = input * dequantize_factor
        return dequantized_input

    def quantize_output(self , output , quantize_factor):
        quantized_output = output * quantize_factor
        quantized_output = np.clip(np.round(quantized_output , decimals = 0) , -128 , 127).astype(np.int8)
        return quantized_output

    def create_host_nodes(self):
        def get_class_from_opr(operation):
            class_object = getattr(self.mod , operation)
            return class_object

        seg_nodes = self.segment_data["nodes"]
        for node_name in seg_nodes:
            node_dict = self.nodes_dict[node_name]
            float_node = get_class_from_opr(node_dict["operation"])(node_dict , node_name , self.const_dict)
            self.float_nodes[node_name] = float_node

    def run_operations(self , input_nodes , input_order , inputs_this_segment):
        node_exec_order = self.segment_data["nodes_order"]
        inp_dep_map = self.segment_data["inp_dep_map"]
        for node_name in node_exec_order:
            inputs = []
            node = self.float_nodes[node_name]
            if node_name in input_nodes:
                input_names_this_node = inp_dep_map[node_name]
                for inp_name in input_names_this_node:
                    if inp_name not in input_order:
                        raise Exception("Required input ", inp_name , " not available")
                    if inp_name not in self.dequant_scales:
                        raise Exception("No dequant scale for input " , inp_name , " whose successor is " , node_name)
                    input = inputs_this_segment[input_order.index(inp_name)]
                    dq_input = self.dequantize_input(input , self.dequant_scales[inp_name])
                    inputs.append(dq_input)
            else:
                for inp_name in node.inputs:
                    if "constant" not in inp_name:
                        inp_node = self.float_nodes[inp_name]
                        inputs.append(inp_node.ouput)

            node.output = node.run(*inputs)

    def get_final_outputs(self , output_nodes , final_segment):
        outputs = []
        for out_name in output_nodes:
            out_node = self.float_nodes[out_name]
            if final_segment:
                outputs.append(out_node.output)
            else:
                if out_name not in self.quant_scales:
                    raise Exception("No quant scale available for node " , out_name)
                quant_out = self.quantize_output(out_node.output , self.quant_scales[out_name])
                outputs.append(quant_out)
        return outputs

    def run_on_host(self , segment_data , inputs_this_segment , input_order , final_segment = False):
        if segment_data["type"] == "BOARD":
            raise Exception("segment runtime type mismatch , expected : HOST , found : BOARD")
        self.segment_data = segment_data
        input_nodes = segment_data["inputs"]
        output_nodes = segment_data["outputs"]
        self.create_host_nodes()
        self.run_operations(input_nodes , input_order , inputs_this_segment)
        outputs_this_segment = self.get_final_outputs(output_nodes , final_segment)
        return outputs_this_segment
