###########################################################################
# Copyright (C) AlphaICs Private Limited, India - All Rights Reserved
#
# Unauthorized copying of this file, via any medium is strictly prohibited
#
# Proprietary and confidential
#
# author : Yogeesh Agarwal <yogeesh.a@alphaics.com> 2021
###########################################################################


from AlphaNE.Runtime_Engine.gluon_runtime import Gluon_Runtime
from AlphaNE.Runtime_Engine.host_runtime import Host_Runtime
from AlphaNE.Runtime_Engine import utils as runtime_utils
import numpy as np
import traceback
import AlphaNE as Ae
import pathlib
import requests
import pickle
import shutil
import json
import pdb
import os

class Runtime():
    def __init__(self,
                 runtime_config_path,
                 constant_dict_path,
                 quant_path,
                 model_name,
                 float_outs = False):
        self.curr_dir_path = os.path.abspath(".")
        self.runtime_path = []
        for name in self.curr_dir_path.split("/"):
            if name == "AlphaNE":
                self.runtime_path.append(name)
                break
            self.runtime_path.append(name)
        self.runtime_path.append("Runtime_Engine")
        self.runtime_path = "/".join(self.runtime_path)
        self.segment_outputs = {}
        self.float_outs = float_outs
        self.quant_path = quant_path
        self.constant_dict_path = constant_dict_path
        self.runtime_config_path = runtime_config_path
        self.runtime_dir= str(pathlib.Path(Ae.__file__).parent)+'/Runtime_Engine/SDKRT/'
        self.input_dir = os.path.join(self.runtime_path , "data/inputs/")
        self.output_dir = os.path.join(self.runtime_path , "data/outputs/")
        self.float_scales_path = os.path.join(self.quant_path , "{}_float_scales.pickle".format(model_name))
        self.input_scale_path = os.path.join(self.quant_path , "{}_input_scale.pickle".format(model_name))
        if os.path.exists(self.input_dir):
            shutil.rmtree(self.input_dir)
        os.makedirs(self.input_dir)
        if os.path.exists(self.output_dir):
            shutil.rmtree(self.output_dir)
        os.makedirs(self.output_dir)
        self.load_config()
        self.gen_quant_dequant_scales()
        self.create_runtimes()

    def create_runtimes(self):
        self.host_runtime = Host_Runtime(self.nodes_dict ,
                                         self.runtime_const_dict ,
                                         self.dequant_scales ,
                                         self.quant_scales)

        self.gluon_runtime = Gluon_Runtime(self.runtime_dir ,
                                           self.input_dir ,
                                           self.output_dir ,
                                           self.runtime_path ,
                                           self.ddr_path ,
                                           self.bin_path ,
                                           self.curr_dir_path ,
                                           self.nodes_dict,
                                           self.dequant_scales)
    def load_json(self , path):
        with open(path) as config:
            json_content = json.loads(config.read())
        return json_content

    def load_npy(self , path):
        npy_content = np.load(path)
        return npy_content

    def load_pickle(self , path):
        with open(path , "rb") as content:
            pickle_content = pickle.load(content)
        return pickle_content

    def gen_quant_dequant_scales(self):
        self.dequant_scales = {}
        self.quant_scales = {}
        for key in self.float_scales:
            self.dequant_scales[key] = 1 / (self.float_scales[key] * self.input_scale)
            self.quant_scales[key] = self.float_scales[key] * self.input_scale

    def load_config(self):
        self.runtime_config = self.load_json(self.runtime_config_path)
        self.ddr_path = self.runtime_config["ddr_path"]
        self.bin_path = self.runtime_config["bin_path"]
        self.nodes_dict = self.runtime_config["node_info"]
        self.segment_dict = self.runtime_config["segment_info"]
        self.input_scale = self.load_pickle(self.input_scale_path)
        self.float_scales = self.load_pickle(self.float_scales_path)
        self.runtime_const_dict = self.load_pickle(self.constant_dict_path)
        self.segment_execution_order = self.runtime_config["segment_info"]["segment_execution_order"]

    def read_outputs(self):
        outputs = runtime_utils.extract_outputs(self.output_dir)
        return outputs

    def write_outputs(self , outputs):
        for output in outputs:
            runtime_utils.write_inp_to_txt(output , self.input_dir)

    def get_final_outputs(self):
        final_outputs = []
        output_segments = self.segment_dict["output_segments"]
        for seg_id in output_segments:
            final_outputs += self.segment_outputs[seg_id]

        return final_outputs

    def run(self , input_image):
        for index , segment_id in enumerate(self.segment_execution_order):
            final_segment = True if segment_id in self.segment_dict["output_segments"] else False
            segment_data = self.segment_dict["segment_data"][str(segment_id)]
            input_segments = segment_data["input_segments"]
            curr_seg_outputs = None
            if len(input_segments) == 0:
                if segment_data["type"] == "HOST":
                    raise Exception("A starting segment of the main graph should be a BOARD type executable")
                starting_inp_addrs = self.segment_dict["starting_inp_addrs"]
                curr_seg_outputs = self.gluon_runtime.run_on_gluon(segment_data ,
                                                                   segment_id ,
                                                                   [input_image] ,
                                                                   final_segment = final_segment ,
                                                                   convert_to_float = self.float_outs ,
                                                                   starting_inp_addrs = starting_inp_addrs)

            else:
                inputs_this_segment = []
                input_order = []
                for inp_seg_id in input_segments:
                    if inp_seg_id not in self.segment_outputs:
                        raise Exception("output of input segment {} for curr segment {} is not computed and hence cannot compute current segment".format(inp_seg_id , segment_data["id"]))
                    inputs_this_segment += self.segment_outputs[inp_seg_id]
                    input_order += self.segment_dict["segment_data"][str(inp_seg_id)]["outputs"]

                if segment_data["type"] == "HOST":
                    curr_seg_outputs = self.host_runtime.run_on_host(segment_data ,
                                                                     inputs_this_segment ,
                                                                     input_order ,
                                                                     final_segment = final_segment)

                elif segment_data["type"] == "BOARD":
                    curr_seg_outputs = self.gluon_runtime.run_on_gluon(segment_data ,
                                                                       segment_id ,
                                                                       inputs_this_segment ,
                                                                       final_segment = final_segment ,
                                                                       convert_to_float = self.float_outs ,
                                                                       input_order = input_order)

                else:
                    raise Exception("Invalid Hardware runtime encountered , " , segment_data["type"])

            if curr_seg_outputs is None:
                raise Exception("None output of the segment " , segment_data["id"] , " encountered")

            self.segment_outputs[segment_id] = curr_seg_outputs

        return self.get_final_outputs()
