./initialize $1
