import numpy as np
import os

def write_inp_to_txt(input , input_path):
    with open(input_path , "w") as file:
        for data in np.array(input).flatten():
            # print(data)
            file.write(str(int(data)) + "\n")

def extract_outputs(output_dir):
    outputs = []
    index = 0
    for _ in os.listdir(output_dir):
        output_path = os.path.join(output_dir , "output_{}".format(index))
        index += 1
        output = []
        with open(output_path , "r") as file:
            data_lines = file.readlines()
            for data in data_lines:
                data = data.strip()
                output.append(int(data))
        outputs.append(np.array(output))
    return outputs
